import 'package:flutter/material.dart';

class Vegetable extends StatelessWidget {
  final List<Map<String, dynamic>> vegetables = [
    {
      'vegetable': 'Lettuce',
      'price': 'GHC 20.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/lettuce.png',
    },
    {
      'vegetable': 'Kontomire',
      'price': 'GHC 20.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/kontomire.png',
    },
    {
      'vegetable': 'Spinach',
      'price': 'GHC 20.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/spinach.png',
    },
    {
      'vegetable': 'Cabbage',
      'price': 'GHC 20.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/cabbage.png',
    },
    {
      'vegetable': 'Beetroot',
      'price': 'GHC 20.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/beetroot.png',
    },
    {
      'vegetable': 'Ayoyo',
      'price': 'GHC 20.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/ayoyo.png',
    },
    {
      'vegetable': 'Bitterleaf',
      'price': 'GHC 20.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/bitterleaf.png',
    },
    {
      'vegetable': 'Kale',
      'price': 'GHC 20.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/kale.png',
    },
    // {
    //   'vegetable': 'Lettuce',
    //   'price': 'GHC 20.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/v1.png',
    // },
    // {
    //   'vegetable': 'Lettuce',
    //   'price': 'GHC 20.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/v1.png',
    // },
    // {
    //   'vegetable': 'Lettuce',
    //   'price': 'GHC 20.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/v1.png',
    // },
    // {
    //   'vegetable': 'Lettuce',
    //   'price': 'GHC 20.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/v1.png',
    // },
  ];

  Vegetable({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GridView.builder(
            padding: EdgeInsets.symmetric(horizontal: 10),
            itemCount: vegetables.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 30,
              crossAxisSpacing: 30,
              childAspectRatio: .5,
            ),
            itemBuilder: (context, index) {
              final vegetable = vegetables[index];
              return Card(
                  elevation: 0.05,
                  shape: ContinuousRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                            child: ClipRRect(
                                borderRadius: BorderRadius.vertical(
                                  top: Radius.circular(12),
                                ),
                                child: Image.asset(
                                  vegetable['image'],
                                  fit: BoxFit.contain,
                                  width: 100,
                                  height: 100,
                                  alignment: Alignment.center,
                                ))),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Text(
                            vegetable['vegetable'],
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Text(
                            vegetable['price'],
                            style: TextStyle(color: Colors.grey),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Text(
                            vegetable['add to cart'],
                            style: TextStyle(color: Colors.grey),
                          ),
                        ),

                        Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8),
                            child: 
                            Divider(
                            thickness: 2,
                            color: Colors.teal,
                          ),
                            ),


                        Padding(
                          padding: EdgeInsetsGeometry.symmetric(horizontal: 10),
                          child: IconButton(onPressed: (){},
                           icon: Icon(Icons.add,
                           color: Colors.teal,
                           size: 25,
                           ))
                        ),
                        
                      ]));
            }));
    
  }
}
