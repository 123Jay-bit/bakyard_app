import 'package:flutter/material.dart';

class Fish extends StatelessWidget {
  final List<Map<String, dynamic>> fishes =[
   {
      'fish': 'Tuna',
      'price': 'GHC 15.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/tuna.png',
    }, 
    {
      'fish': 'Salmon Fish',
      'price': 'GHC 15.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/salmon.png',
    }, 
    {
      'fish': 'Tilapia',
      'price': 'GHC 15.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/tilapia.png',
    }, 
    {
      'fish': 'Catfish',
      'price': 'GHC 15.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/catfish.png',
    }, 
  ];
   Fish({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GridView.builder(
        padding: EdgeInsets.symmetric(horizontal: 10),
        itemCount: fishes.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 30,
          crossAxisSpacing: 30,
          childAspectRatio: .5,
        ),
        itemBuilder: (context, index) {
          final fish = fishes[index];
          return Card(
            elevation: 0.05,
            shape: ContinuousRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(12),
                    ),
                    child: Image.asset(
                      fish['image'],
                      fit: BoxFit.contain,
                      width: 100,
                      height: 100,
                      alignment: Alignment.center,
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8),
                  child: Text(
                    fish['fish'],
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8),
                  child: Text(
                    fish['price'],
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8),
                  child: Text(
                    fish['add to cart'],
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8),
                  child: Divider(thickness: 2, color: Colors.teal),
                ),
                Padding(
                  padding: EdgeInsetsGeometry.symmetric(horizontal: 10),
                  child: IconButton(
                    onPressed: () {},
                    icon: Icon(Icons.add, color: Colors.teal, size: 25),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}