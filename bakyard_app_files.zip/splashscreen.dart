import 'package:flutter/material.dart';
import 'package:bakyard/welcomescreen.dart'; // Make sure this import is correct

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 7), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const Welcomescreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFF00A878),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 40),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Bak",
                    style: TextStyle(
                      fontSize: 64,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 150),
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Yard",
                      style: TextStyle(
                        fontSize: 64,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Bringing farms\nto your",
                    style: TextStyle(
                      fontSize: 20,
                      fontStyle: FontStyle.italic,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 50),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Text(
                      "Doorsteps",
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87,
                      ),
                    ),
                  ),
                  SizedBox(height: 40),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}









// appBar: AppBar(
//         backgroundColor: Colors.teal,
//         leading: IconButton(
//           onPressed: () {},
//           icon: Icon(Icons.arrow_circle_left_sharp, color: Colors.black),
//         ),

//         title: Container(
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(20),
//           ),
//           child: TextField(
//             decoration: InputDecoration(
//               prefixIcon: Icon(
//                 Icons.search_rounded,
//                 size: 30,
//                 color: Colors.black,
//               ),
//               hintText: 'Search',
//               hintStyle: TextStyle(fontStyle: FontStyle.italic),
//             ),
//           ),
//         ),
//         centerTitle: true,

//         bottom: TabBar(
//           controller: tabController,
//           indicatorColor: Colors.black,
//           tabs: [
//             Text(
//               "Products",
//               style: TextStyle(
//                 color: Colors.white,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             Text(
//               "Vendors",
//               style: TextStyle(
//                 color: Colors.white,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             Text(
//               "Farmers",
//               style: TextStyle(
//                 color: Colors.white,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//           ],
//         ),
//         elevation: 5.0,
//         scrolledUnderElevation: 5.0,
//         shadowColor: Colors.grey,
//       ),
