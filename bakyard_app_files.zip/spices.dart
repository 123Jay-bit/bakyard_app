import 'package:bakyard/commonspices.dart';
import 'package:bakyard/fruits.dart';
import 'package:bakyard/packagedspices.dart';
import 'package:flutter/material.dart';

class Spices extends StatefulWidget {
  const Spices({super.key});

  @override
  State<Spices> createState() => _SpicesState();
}

class _SpicesState extends State<Spices>  with SingleTickerProviderStateMixin {
  TabController? tabController;
  
   @override
  void initState() {
    tabController = TabController(length: 2, vsync: this);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 3,
        bottom: 
        TabBar(
          controller: tabController,
                    isScrollable: false,
                    indicatorColor: Colors.teal,
                    tabs: [
                      Text(
                        "Common Spices",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      Text(
              "Packaged Spices",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
              ),
            ),
                    ]
        )),

      body: 
         Expanded(
        child: TabBarView(
          controller: tabController,
          children: [
            Commonspices(),
             Packagedspices(),
    ])));
  }
}