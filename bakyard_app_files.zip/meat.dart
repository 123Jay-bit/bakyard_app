import 'package:flutter/material.dart';

class Meat extends StatelessWidget {
   final List<Map<String, dynamic>> meats =[
    {
      'meat': 'Chicken',
      'price': 'GHC 5.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/chicken.png',
    },
    {
      'meat': 'Rabbit',
      'price': 'GHC 5.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/rabbit.png',
    },
    {
      'meat': 'Goat Meat',
      'price': 'GHC 5.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/goatmeat.png',
    },
    // {
    //   'meat': 'Chicken',
    //   'price': 'GHC 5.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/chicken.png',
    // },
    // {
    //   'meat': 'Chicken',
    //   'price': 'GHC 5.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/chicken.png',
    // },
    // {
    //   'meat': 'Chicken',
    //   'price': 'GHC 5.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/chicken.png',
    // },
    // {
    //   'meat': 'Chicken',
    //   'price': 'GHC 5.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/chicken.png',
    // },
    // {
    //   'meat': 'Chicken',
    //   'price': 'GHC 5.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/chicken.png',
    // },
    // {
    //   'meat': 'Chicken',
    //   'price': 'GHC 5.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/chicken.png',
    // },
    // {
    //   'meat': 'Chicken',
    //   'price': 'GHC 5.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/chicken.png',
    // },
    // {
    //   'meat': 'Chicken',
    //   'price': 'GHC 5.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/chicken.png',
    // },
    // {
    //   'meat': 'Chicken',
    //   'price': 'GHC 5.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/chicken.png',
    // },
   ];
  Meat({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GridView.builder(
        padding: EdgeInsets.symmetric(horizontal: 10),
        itemCount: meats.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 30,
          crossAxisSpacing: 30,
          childAspectRatio: .5,
        ),
        itemBuilder: (context, index) {
          final meat = meats[index];
          return Card(
            elevation: 0.05,
            shape: ContinuousRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(12),
                    ),
                    child: Image.asset(
                      meat['image'],
                      fit: BoxFit.contain,
                      width: 100,
                      height: 100,
                      alignment: Alignment.center,
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8),
                  child: Text(
                    meat['meat'],
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8),
                  child: Text(
                    meat['price'],
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8),
                  child: Text(
                    meat['add to cart'],
                    style: TextStyle(color: Colors.grey),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8),
                  child: Divider(thickness: 2, color: Colors.teal),
                ),

                Padding(
                  padding: EdgeInsetsGeometry.symmetric(horizontal: 10),
                  child: IconButton(
                    onPressed: () {},
                    icon: Icon(Icons.add, color: Colors.teal, size: 25),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}