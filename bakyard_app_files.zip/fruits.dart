import 'package:flutter/material.dart';

class Fruits extends StatelessWidget {
  final List<Map<String, dynamic>> fruits = [
    
    {
      'fruit': 'Apple',
      'price': 'GHC 10.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/apple.png',
    },
    {
      'fruit': 'Avocado',
      'price': 'GHC 10.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/avocado.png',
    },
    {
      'fruit': 'Amaranthus',
      'price': 'GHC 10.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/Amaranthus.png',
    },
    {
      'fruit': 'Guava',
      'price': 'GHC 10.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/guava.png',
    },
    {
      'fruit': 'Pawpaw',
      'price': 'GHC 10.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/pawpaw.png',
    },
    {
      'fruit': 'Pumpkin',
      'price': 'GHC 10.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/pumpkin.png',
    },
    // {
    //   'fruit': 'Orange',
    //   'price': 'GHC 10.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/v1.png',
    // },
    // {
    //   'fruit': 'Orange',
    //   'price': 'GHC 10.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/v1.png',
    // },
    // {
    //   'fruit': 'Orange',
    //   'price': 'GHC 10.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/v1.png',
    // },
    // {
    //   'fruit': 'Orange',
    //   'price': 'GHC 10.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/v1.png',
    // },
  ];
  Fruits({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: GridView.builder(
            padding: EdgeInsets.symmetric(horizontal: 10),
            itemCount: fruits.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 30,
              crossAxisSpacing: 30,
              childAspectRatio: .5,
            ),
            itemBuilder: (context, index) {
              final fruit = fruits[index];
              return Card(
                  elevation: 0.05,
                  shape: ContinuousRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                            child: ClipRRect(
                                borderRadius: BorderRadius.vertical(
                                  top: Radius.circular(12),
                                ),
                                child: Image.asset(
                                  fruit['image'],
                                  fit: BoxFit.contain,
                                  width: 100,
                                  height: 100,
                                  alignment: Alignment.center,
                                ))),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Text(
                            fruit['fruit'],
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Text(
                            fruit['price'],
                            style: TextStyle(color: Colors.grey),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Text(
                            fruit['add to cart'],
                            style: TextStyle(color: Colors.grey),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Divider(
                            thickness: 2,
                            color: Colors.teal,
                          ),
                        ),
                        Padding(
                            padding:
                                EdgeInsetsGeometry.symmetric(horizontal: 10),
                            child: IconButton(
                                onPressed: () {},
                                icon: Icon(
                                  Icons.add,
                                  color: Colors.teal,
                                  size: 25,
                                ))),
                      ]));
            }));
  }
}
