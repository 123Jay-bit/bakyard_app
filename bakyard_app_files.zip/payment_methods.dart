import 'package:flutter/material.dart';

class PaymentMethods extends StatelessWidget {
  const PaymentMethods({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(
        leading: IconButton(
          onPressed: () {},
          icon: Icon(Icons.arrow_circle_left_sharp, size: 20),
        ),
        centerTitle: true,
        title: Text(
          "Payment methods",
          style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
        ),
      ),

      body: 
      SingleChildScrollView(
        padding: EdgeInsets.all(8),
        
        child: 
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
             // color: Colors.grey,
              height: 80, width: 400 ,
              
              decoration: BoxDecoration(
                border: Border(
                  left: BorderSide(
                    style: BorderStyle.solid,
                    color: Colors.black
                  ),
                  right: BorderSide(
                    style: BorderStyle.solid,
                    color: Colors.black
                  ),
                  top: BorderSide(
                    style: BorderStyle.solid,
                    color: Colors.black
                  ),
                  bottom: BorderSide(
                    
                    style: BorderStyle.solid,
                    color: Colors.black
                  )
                ),
                
                borderRadius: BorderRadius.circular(10),
                //color: Colors.black,
                
              ),
              
              child: 
              Column(
                children: [
                  SizedBox(height: 5,),
                  Align(
                    alignment: 
                    Alignment.bottomRight,
                    child: 
                    Column(
                      children: [
                        Row(
                          children: [
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Icon(Icons.paypal),
                            ),
                            SizedBox(width: 100,),

                            Align(alignment: Alignment.center,
                            child: Text('**** **** **** 5489',
                            style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                            )
                            ,),
                            SizedBox(width: 50,),
                            Align(
                              alignment: Alignment.centerRight,
                              child: SizedBox(
                                height: 20,
                                width: 40,
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.teal,
                                    shape: RoundedRectangleBorder(),
                                    padding: EdgeInsets.zero
                                  ),
                                  onPressed: () {},
                                  child: Text('Edit',
                                  style: TextStyle(
                                    fontFamily: 'Poppins',
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black
                                  ),
                                  textAlign: TextAlign.center,),
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 2,),
                        Align(alignment: Alignment.center,
                        child: Text('Jacob Amponsah Koomson',
                        style: TextStyle(
                              fontFamily: 'Poppins',
                              fontSize: 18,
                              //fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),)
                        
                        ],
                    ),
                  )
                ],
              ),
            ),
            SizedBox(height: 5,),

            Container(
              // color: Colors.grey,
              height: 90,
              width: 400,

              decoration: BoxDecoration(
                border: Border(
                  left: BorderSide(
                    style: BorderStyle.solid,
                    color: Colors.black,
                  ),
                  right: BorderSide(
                    style: BorderStyle.solid,
                    color: Colors.black,
                  ),
                  top: BorderSide(
                    style: BorderStyle.solid,
                    color: Colors.black,
                  ),
                  bottom: BorderSide(
                    style: BorderStyle.solid,
                    color: Colors.black,
                  ),
                ),

                borderRadius: BorderRadius.circular(10),

                //color: Colors.black,
              ),

              child: Column(
                children: [
                  SizedBox(height: 5),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Align(
                              alignment: Alignment.centerLeft,
                              child: 
                              Image.asset('assets/images/visacard.jpg',
                              filterQuality: FilterQuality.high,
                              
                              height: 28,
                              width: 24,
                              fit: BoxFit.contain,
                              ),
                            ),
                            SizedBox(width: 100),

                            Align(
                              alignment: Alignment.center,
                              child: Text(
                                '**** **** **** 6530',
                                style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                            SizedBox(width: 50),
                            Align(
                              alignment: Alignment.centerRight,
                              child: SizedBox(
                                height: 20,
                                width: 40,
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.teal,
                                    shape: RoundedRectangleBorder(),
                                    padding: EdgeInsets.zero,
                                  ),
                                  onPressed: () {},
                                  child: Text(
                                    'Edit',
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: .5),
                        Align(
                          alignment: Alignment.center,
                          child: Text(
                            'expires',
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontSize: 18,
                              //fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ),
                        SizedBox(height: .5),
                        Align(
                          alignment: Alignment.center,
                          child: Text(
                            'dd/mm/yy',
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontSize: 18,
                              //fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            SizedBox(height: 5),

            Container(
              // color: Colors.grey,
              height: 90,
              width: 400,

              decoration: BoxDecoration(
                border: Border(
                  left: BorderSide(
                    style: BorderStyle.solid,
                    color: Colors.black,
                  ),
                  right: BorderSide(
                    style: BorderStyle.solid,
                    color: Colors.black,
                  ),
                  top: BorderSide(
                    style: BorderStyle.solid,
                    color: Colors.black,
                  ),
                  bottom: BorderSide(
                    style: BorderStyle.solid,
                    color: Colors.black,
                  ),
                ),

                borderRadius: BorderRadius.circular(10),

                //color: Colors.black,
              ),

              child: Column(
                children: [
                  SizedBox(height: 5),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Image.asset(
                                'assets/images/vodacash.jpg',

                                height: 28,
                                width: 24,
                                fit: BoxFit.contain,
                              ),
                            ),
                            SizedBox(width: 100),

                            Align(
                              alignment: Alignment.center,
                              child: Text(
                                '0202216406',
                                style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                            SizedBox(width: 85),
                            Align(
                              alignment: Alignment.centerRight,
                              child: SizedBox(
                                height: 20,
                                width: 40,
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.teal,
                                    shape: RoundedRectangleBorder(),
                                    padding: EdgeInsets.zero,
                                  ),
                                  onPressed: () {},
                                  child: Text(
                                    'Edit',
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: .5),
                        Align(
                          alignment: Alignment.center,
                          child: Text(
                            'Voda Cash',
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontSize: 18,
                              //fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ),
                        SizedBox(height: .5),
                        Align(
                          alignment: Alignment.center,
                          child: Text(
                            '',
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontSize: 18,
                              //fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),


            SizedBox(height: 5),

            Container(
              // color: Colors.grey,
              height: 90,
              width: 400,

              decoration: BoxDecoration(
                border: Border(
                  left: BorderSide(
                    style: BorderStyle.solid,
                    color: Colors.black,
                  ),
                  right: BorderSide(
                    style: BorderStyle.solid,
                    color: Colors.black,
                  ),
                  top: BorderSide(
                    style: BorderStyle.solid,
                    color: Colors.black,
                  ),
                  bottom: BorderSide(
                    style: BorderStyle.solid,
                    color: Colors.black,
                  ),
                ),

                borderRadius: BorderRadius.circular(10),

                //color: Colors.black,
              ),

              child: Column(
                children: [
                  SizedBox(height: 5),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Image.asset(
                                'assets/images/momo.png',

                                height: 28,
                                width: 24,
                                fit: BoxFit.contain,
                              ),
                            ),
                            SizedBox(width: 100),

                            Align(
                              alignment: Alignment.center,
                              child: Text(
                                '0240433781',
                                style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                            SizedBox(width: 85),
                            Align(
                              alignment: Alignment.centerRight,
                              child: SizedBox(
                                height: 20,
                                width: 40,
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.teal,
                                    shape: RoundedRectangleBorder(),
                                    padding: EdgeInsets.zero,
                                  ),
                                  onPressed: () {},
                                  child: Text(
                                    'Edit',
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: .5),
                        Align(
                          alignment: Alignment.center,
                          child: Text(
                            'MTN MOMO',
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontSize: 18,
                              //fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ),
                        SizedBox(height: .5),
                        Align(
                          alignment: Alignment.center,
                          child: Text(
                            '',
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontSize: 18,
                              //fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}