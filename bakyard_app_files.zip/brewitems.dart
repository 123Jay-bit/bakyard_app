import 'package:flutter/material.dart';

class Brewitems extends StatelessWidget {
  final List<Map<String, dynamic>> brewsitems =[
    {
      'brewitem': 'Lipton',
      'price': 'GHC 5.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/lipton.png',
    },
     {
      'brewitem': 'Bread',
      'price': 'GHC 5.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/bread.png',
    },
     {
      'brewitem': 'Egg',
      'price': 'GHC 5.00',
      '': '',
      'add to cart': '',
      'image': 'assets/images/egg.png',
    },
    //  {
    //   'brewitem': 'Lipton',
    //   'price': 'GHC 5.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/lipton.png',
    // },
    //  {
    //   'brewitem': 'Lipton',
    //   'price': 'GHC 5.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/lipton.png',
    // },
    //  {
    //   'brewitem': 'Lipton',
    //   'price': 'GHC 5.00',
    //   '': '',
    //   'add to cart': '',
    //   'image': 'assets/images/lipton.png',
    // },

  ];
   Brewitems({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GridView.builder(
        padding: EdgeInsets.symmetric(horizontal: 10),
        itemCount: brewsitems.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 30,
          crossAxisSpacing: 30,
          childAspectRatio: .5,
        ),
        itemBuilder: (context, index) {
          final brewitem = brewsitems[index];
          return Card(
            elevation: 0.05,
            shape: ContinuousRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(12),
                    ),
                    child: Image.asset(
                      brewitem['image'],
                      fit: BoxFit.contain,
                      width: 100,
                      height: 100,
                      alignment: Alignment.center,
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8),
                  child: Text(
                    brewitem['brewitem'],
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8),
                  child: Text(
                    brewitem['price'],
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8),
                  child: Text(
                    brewitem['add to cart'],
                    style: TextStyle(color: Colors.grey),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8),
                  child: Divider(thickness: 2, color: Colors.teal),
                ),

                Padding(
                  padding: EdgeInsetsGeometry.symmetric(horizontal: 10),
                  child: IconButton(
                    onPressed: () {},
                    icon: Icon(Icons.add, color: Colors.teal, size: 25),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
}
}