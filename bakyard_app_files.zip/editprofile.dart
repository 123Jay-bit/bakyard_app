import 'package:flutter/material.dart';

class Editprofile extends StatefulWidget {
  const Editprofile({super.key});

  @override
  State<Editprofile> createState() => _EditprofileState();
}

class _EditprofileState extends State<Editprofile> {
  String _userSelectedStatus = '';

  final List<String> _statusOPtions = ['C', 'V', 'F'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Title(
          color: Colors.teal,
          child: Align(
            alignment: Alignment.center,
            child: Container(
              width: 90, // Set your desired size
              height: 90,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.black,
                  style: BorderStyle.solid,
                ),
              ),
              child: ClipOval(
                child: Image.asset(
                  'assets/images/f3.png',
                  fit: BoxFit.cover,
                  width: 90,
                  height: 90,
                ),
              ),
            ),
          ),
        ),
        centerTitle: true,
        toolbarHeight: 150,
        leadingWidth: 1,
        backgroundColor: Colors.teal,
        leading: Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            children: [
              // Align(
              //    // alignment: Alignment.center,
              //     child: Column(
              //       children: [
              //         Container(//width: 1.5,
              //           decoration: BoxDecoration(
              //             border: BoxBorder.all(
              //               color: Colors.grey,
              //               //width: 1.5,
              //             ),
              //             shape: BoxShape.circle,
              //             image: DecorationImage(
              //               image: AssetImage('assets/images/f3.png'),
              //               fit: BoxFit.contain,
              //               filterQuality: FilterQuality.high,
              //             ),
              //           ),
              //         ),
              //       ],
              //     ),
              //   )
            ],
          ),
        ),
      ),

      body: Expanded(
        child: Container(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  'Edit Profile',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                SizedBox(height: 25),

                //Text('Fullname',),
                TextFormField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.black, width: 0.5),
                    ),
                    label: Text('Fullname'),
                  ),
                ),

                SizedBox(height: 10),

                TextFormField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.black, width: 0.5),
                    ),
                    label: Text('Username'),
                  ),
                ),

                SizedBox(height: 10),

                TextFormField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.black, width: 0.5),
                    ),
                    label: Text('Email'),
                  ),
                ),

                SizedBox(height: 10),

                TextFormField(
                  //autofillHints: Iterable.generate(90),
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.black, width: 0.5),
                    ),
                    label: Text('Phone Number'),
                  ),
                ),

                SizedBox(height: 10),

                TextFormField(
                  //autofillHints: Iterable.generate(90),
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.black, width: 0.5),
                    ),
                    label: Text('GPS Address'),
                  ),
                ),

                SizedBox(height: 25),

                Row(
                  //crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'User Status',
                      style: TextStyle(
                        fontFamily: 'Poppins semi bold',
                        fontSize: 18,
                      ),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(width: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: _statusOPtions.map((status) {
                        bool isSelected = _userSelectedStatus == status;
                        return Padding(
                          padding: const EdgeInsets.only(right: 5.0),
                          child: Row(
                            children: [
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    _userSelectedStatus = status;
                                  });
                                },

                                child: Container(
                                  constraints: BoxConstraints(
                                    minWidth: 40,
                                    minHeight: 40,
                                    maxWidth: 40,
                                    maxHeight: 40,
                                  ),
                                  decoration: BoxDecoration(
                                    color: isSelected
                                        ? Colors.grey
                                        : Colors.transparent,
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: Colors.black,
                                      width: 1,
                                      style: BorderStyle.solid,
                                    ),
                                  ),

                                  child: Padding(
                                    padding: const EdgeInsets.all(5),
                                    child:
                                        // Row(
                                        //   children: [
                                        //     SizedBox(width: ,)
                                        //   ],
                                        // )
                                        Text(status[0], style: TextStyle()),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
                SizedBox(height: 5),
                Text('Please note: C = "Consumer", v ="Vendor", F = "Farmer"',
                style: TextStyle(color: Colors.red),),

                SizedBox(height: 80),

                SizedBox(
                  height: 50,
                  width: 300,
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                        side: BorderSide(color: Colors.grey, width: .5),
                      ),
                    ),
                    child: Text(
                      'Save',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Poppins SemiBold',
                        color: Colors.white,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
