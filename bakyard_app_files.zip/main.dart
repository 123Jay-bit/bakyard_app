import 'package:device_preview/device_preview.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:convert';

import 'package:badges/badges.dart' as badges;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:bakyard/main.dart';
import 'package:bakyard/splashscreen.dart';
import 'package:bakyard/products.dart';
import 'package:bakyard/vegetable.dart';
import 'package:bakyard/welcomescreen.dart';
import 'package:bakyard/signup_pge.dart';
import 'package:bakyard/loginpge.dart';
import 'package:bakyard/loginpge2.dart';
import 'package:bakyard/vendors.dart';
import 'package:bakyard/signup_pge_vendors.dart';
import 'package:bakyard/signup_pge_farmers.dart';
import 'package:bakyard/profile.dart';
import 'package:bakyard/home_pge.dart';
import 'package:bakyard/fruits.dart';
import 'package:bakyard/farmers.dart';
import 'package:bakyard/basket.dart';
import 'package:bakyard/d.dart';
import 'package:bakyard/editprofile.dart';
import 'package:bakyard/OrderSummary.dart';
//import 'package:bakyard/a.dart';
import 'package:bakyard/payment_methods.dart';

Future<void> main() async {
  runApp(
    DevicePreview(enabled: !kReleaseMode, builder: (context) => const MyApp()),
  );
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      
    ),
  );
}

// Future<void> uploadSampleData() async {
//   final firestore = FirebaseFirestore.instance;
//   final String jsonString = await rootBundle.loadString(
//     'assets/database/bakyard_sample_data.json',
//   );
//   final Map<String, dynamic> jsonData = jsonDecode(jsonString);
//   for (var name in jsonData['users']) {
//     await firestore.collection('users').add(name);
//   }

//   for (var vendor in jsonData['vendors']) {
//     await firestore.collection('vendors').add(vendor);
//   }

//   for (var farmer in jsonData['farmers']) {
//     await firestore.collection('farmers').add(farmer);
//   }
// }

// Future<void> uploadGroupedProducts() async {
//   final String jsonString = await rootBundle.loadString(
//     'assets/database/bakyard_sample_data.json',
//   );
//   final Map<String, dynamic> jsonData = jsonDecode(jsonString);

//   for (var category in jsonData['ProductCategory']) {
//     //Add the category and get auto-generated ID
//     DocumentReference categoryRef = await FirebaseFirestore.instance
//         .collection('ProductCategories')
//         .add({'name': category['name']});

//     for (var product in category['products']) {
//       await categoryRef.collection('products').add({
//         'name': product['name'],
//         'price': product['price'],
//         'image': product[''],
//       });
//     }
//   }
// }

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // ignore: deprecated_member_use
      useInheritedMediaQuery: true,
      locale: DevicePreview.locale(context),
      builder: DevicePreview.appBuilder,

      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // TRY THIS: Try running your application with "flutter run". You'll see
        // the application has a purple toolbar. Then, without quitting the app,
        // try changing the seedColor in the colorScheme below to Colors.green
        // and then invoke "hot reload" (save your changes or press the "hot
        // reload" button in a Flutter-supported IDE, or press "r" if you used
        // the command line to start the app).
        //
        // Notice that the counter didn't reset back to zero; the application
        // state is not lost during the reload. To reset the state, use hot
        // restart instead.
        //
        // This works for code too, not just values: Most code changes can be
        // tested with just a hot reload.
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: HomePge(), 
      debugShowCheckedModeBanner: false,
      routes: {
        '/splash': (context) => const SplashScreen(),
        '/welcome': (context) => const Welcomescreen(),
        '/signup': (context) => const SignupPge(),

        '/home': (context) => const HomePge(),
        '/products': (context) => const Products(),
        '/vegetable': (context) =>  Vegetable(),
        // '/login': (context) => const LoginPage(),
        // '/login2': (context) => const LoginPage2(),
        // '/vendors': (context) => const Vendors(),
        // '/signup_vendors': (context) => const SignUpPageVendors(),
        // '/signup_farmers': (context) => const SignUpPageFarmers(),
        // '/profile': (context) => const ProfilePage(),
        // '/fruits': (context) => const Fruits(),
        // '/farmers': (context) => const Farmers(),
        // '/basket': (context) => const BasketPage(),
        // '/d': (context) => const DPage(),
        // '/editprofile': (context) => const EditProfilePage(),
        // '/ordersummary': (context) => const OrderSummaryPage(),
        // //'/a':(context)=>const APage(), 
        // '/payment_methods':(context)=>const PaymentMethodsPage()
      },
    );
  }
}


// download these dependencies
// firebase_auth
// firebase_core
// cloud_firestore