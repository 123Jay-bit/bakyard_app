import 'package:flutter/material.dart';

class OrderSummary extends StatelessWidget {
  const OrderSummary({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: 
      AppBar(
        leading: IconButton(onPressed: (){},
         icon: Icon(Icons.arrow_circle_left_sharp,
         size: 20,)),
         centerTitle: true,
         title: Text("Order Summary",
         style: TextStyle(
          fontSize: 25,
          fontWeight: FontWeight.bold,
         ),),

      ),
      body: 
      SingleChildScrollView(
        child:
         Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: 
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            
            Align(
              alignment: 
              Alignment.center,
              child: 
              Column(
                children: [
                  Container(
                        height: 200,
                        width: 380,
                        color: Colors.grey,
                        child: Column(
                          children: [
                            Align(
                              alignment: Alignment.center,
                              child: Text('Order list',
                              style: TextStyle(
                                fontSize: 20,
                                fontFamily: 'poppins',
                                fontWeight: FontWeight.bold,
                              ),),
                            ),
                            
                            SizedBox(height: 5),

                            Row(
                              children: [
                                Text('Item1'),
                                SizedBox(width: 250),
                                Text('20,000.00'),
                              ],
                            ),
                            SizedBox(height: 5),
                            Row(
                              children: [
                                Text('Item2'),
                                SizedBox(width: 250),
                                Text('20,000.00'),
                              ],
                            ),
                            SizedBox(height: 5),
                            Row(
                              children: [
                                Text('Item3'),
                                SizedBox(width: 250),
                                Text('20,000.00'),
                              ],
                            ),
                            SizedBox(height: 5),
                            Row(
                              children: [
                                Text('Item4'),
                                SizedBox(width: 250),
                                Text('20,000.00'),
                                
                              ],
                            ),
                            SizedBox(height: 10),
                            Row(
                              children: [
                                Text(
                                  'Grand Total',
                                  style: TextStyle(
                                    fontFamily: 'Popiins',
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(width: 170),
                                Text('GHC',
                                style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  ),),
                                SizedBox(width: 2),
                                Text(
                                  '20,000.00',
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),

                      SizedBox(height: 20),

                      Container(
                      height: 200,
                      width: 380,
                      color: Colors.grey,
                      child: Column(
                        children: [
                          Align(
                            alignment: Alignment.center,
                            child: Text(
                              'Order list',
                              style: TextStyle(
                                fontSize: 20,
                                fontFamily: 'poppins',
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),

                          SizedBox(height: 5),

                          Row(
                            children: [
                              Text('Item1'),
                              SizedBox(width: 250),
                              Text('20,000.00'),
                            ],
                          ),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Text('Item2'),
                              SizedBox(width: 250),
                              Text('20,000.00'),
                            ],
                          ),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Text('Item3'),
                              SizedBox(width: 250),
                              Text('20,000.00'),
                            ],
                          ),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Text('Item4'),
                              SizedBox(width: 250),
                              Text('20,000.00'),
                            ],
                          ),
                          SizedBox(height: 10),
                          Row(
                            children: [
                              Text(
                                'Grand Total',
                                style: TextStyle(
                                  fontFamily: 'Popiins',
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(width: 170),
                              Text(
                                'GHC',
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(width: 2),
                              Text(
                                '20,000.00',
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  
                ],
              ),
            )
          ],
        ),
        ) ,
      ),   
         );
  }
}